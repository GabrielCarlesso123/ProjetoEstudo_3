import './style.css'
import '../src/exemplos/vector2'
import '../src/exemplos/pessoa'
import '../src/exemplos/listas'

console.log('abc')
