import { Pessoa } from "./pessoa"

const listaDePessoas: Pessoa[] = []

listaDePessoas.push(
    {nome: 'Ana', idade: 23},
    {nome: 'Gui', idade: 25},
    {nome: 'Thiago', idade: 43}
)

listaDePessoas.forEach((element) => console.log(element))

//console.table(listaDePessoas)